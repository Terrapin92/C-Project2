# CMSC330_P2
CMSC330 Project 2

Compile command:

```bash
g++ *.cpp
```

Binary is `a.out`.
