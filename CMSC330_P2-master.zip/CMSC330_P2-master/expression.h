class Expression {
	public:
		virtual double evaluate() = 0;
};
