void parseVars(stringstream& in);
