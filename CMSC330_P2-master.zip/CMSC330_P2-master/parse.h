string parseName(stringstream &in);
